#!/bin/bash

if [[ "$1" == "-h" ]]; then
    echo "Argumentos: ruta_de_origen ruta_de_destino
Descripción: Comprime el directorio o archivo que se encuentra en ruta_de_origen y lo deja en ruta_de_destino"

elif [[ $# -ne 2 ]]; then
    echo "Error: Se requieren dos parámetros."

else
	RUTA_ORIGEN=$1
	RUTA_DESTINO=$2
	if [ ! -e "$RUTA_ORIGEN" ]; then
    		echo "La ruta destino no existe."
		exit 1
	fi

	if [ ! -e "$RUTA_DESTINO" ]; then
		echo "La ruta de origen no existe."
		exit 1
	fi
	
	FECHA=$(date +%Y%m%d)
	NOMBRE_ARCHIVO=$(basename "$RUTA_ORIGEN")
	NOMBRE_ARCHIVO=${NOMBRE_ARCHIVO#.}
	RUTA_FINAL="$RUTA_DESTINO${NOMBRE_ARCHIVO}_backup_$FECHA.tar.gz"
	
	echo "Cambiando a ruta de origen"
	cd $RUTA_ORIGEN
	cd ..
	echo "Comprimiendo archivo"
	tar -czvf $RUTA_FINAL ./$NOMBRE_ARCHIVO 	
	echo Terminado

fi
