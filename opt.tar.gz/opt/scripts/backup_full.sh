
#!/bin/bash

#Valido si existe el archivo y si esta montado
validar_archivos(){
#Todo validar que los archivos esten montados
	if [ ! -d "${DEST_DIR}" ]; then
		echo "El directorio destino '${DEST_DIR}' no existe o no esta montado correctamente"
		exit 1
	fi
	if [ ! -d "${SOURCE_DIR}" ]; then
		echo "El directorio de origen '${SOURCE_DIR}' no existe o no esta montado correctamente"
		exit 1
	fi

}
crear_archivo_bkp(){
validar_archivos
NOMBRE_ARCHIVO=$(basename "$SOURCE_DIR")
NOMBRE_ARCHIVO=${NOMBRE_ARCHIVO#.}
BACKUP_FILE="$DEST_DIR${NOMBRE_ARCHIVO}_bkp_$CURRET_DATE.tar.gz"
cd $SOURCE_DIR
cd ..
echo "Creando backup de ${SOURCE_DIR} en ${DEST_DIR} con el nombre ${BACKUP_FILE}"
tar -czf "$BACKUP_FILE" $SOURCE_DIR
echo "Backup completado"
}



if [ $1 == "-h" ]; then
	echo "Ha ingresado al modo ayuda"
	echo "Este script se ejecuta mediante un cron o manualmente. Para ejecutarlo de forma manual debe pasar como argumento el archivo de origen y el archivo de destino del backup"
	exit 1
elif [ $# -ne "2" ]; then
	echo "Error: Debe ingresar 2 parametros"
else
	SOURCE_DIR=$1
	DEST_DIR=$2
	CURRENT_DATE=$(date +%Y%m%d)
	crear_archivo_bkp
fi
